#!/bin/bash

FLOUR=$1
echo "LOG --> Shopping for $FLOUR ounces of flour at the groccery store..."
mkdir -p cart
> cart/flour.item
for ((i=0; i<=$flour; i++)); do							echo "flour$i" >> cart/flour.item					done

